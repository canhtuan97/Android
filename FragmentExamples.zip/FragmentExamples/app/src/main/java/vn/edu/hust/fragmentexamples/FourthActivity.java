package vn.edu.hust.fragmentexamples;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class FourthActivity extends AppCompatActivity implements View.OnClickListener {

    int fragmentIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth);

        fragmentIndex = 0;

        findViewById(R.id.btn_add).setOnClickListener(this);
        findViewById(R.id.btn_replace).setOnClickListener(this);
        findViewById(R.id.btn_pop).setOnClickListener(this);
        findViewById(R.id.btn_remove).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_add) {
            fragmentIndex++;

            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            BlueFragment blueFragment = BlueFragment.newInstance(String.valueOf(fragmentIndex), "");
            ft.add(R.id.fragment_layout, blueFragment, "BLUE-TAG");
            ft.addToBackStack("BLUE");
            ft.commit();
        } else if (id == R.id.btn_replace) {
            fragmentIndex++;

            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            BlueFragment blueFragment = BlueFragment.newInstance(String.valueOf(fragmentIndex), "");
            ft.replace(R.id.fragment_layout, blueFragment, "BLUE-TAG");
            ft.addToBackStack("BLUE");
            ft.commit();
        } else if (id == R.id.btn_pop) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStackImmediate();
        } else if (id == R.id.btn_remove) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            Fragment fragment = fragmentManager.findFragmentByTag("BLUE-TAG");
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.remove(fragment);
            ft.commit();
        }
    }
}
