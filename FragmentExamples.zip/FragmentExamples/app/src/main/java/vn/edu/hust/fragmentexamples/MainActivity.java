package vn.edu.hust.fragmentexamples;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    RedFragment redFragment;
    BlueFragment blueFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        redFragment = new RedFragment();
        blueFragment = BlueFragment.newInstance("Param 1", "Param 2");

        findViewById(R.id.btn_add_red).setOnClickListener(this);
        findViewById(R.id.btn_add_blue).setOnClickListener(this);
        findViewById(R.id.btn_replace_blue).setOnClickListener(this);
        findViewById(R.id.btn_remove_blue).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btn_add_red) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.add(R.id.fragment_layout_red, redFragment);
            ft.commit();
        } else if (id == R.id.btn_add_blue) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.add(R.id.fragment_layout_blue, blueFragment);
            ft.commit();
        } else if (id == R.id.btn_replace_blue) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.fragment_layout_blue, blueFragment);
            ft.commit();
        }  else if (id == R.id.btn_remove_blue) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.remove(blueFragment);
            ft.commit();
        }
    }
}
